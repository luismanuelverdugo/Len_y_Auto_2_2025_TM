package com.analizador.util;

import com.analizador.model.Simbolo;
import com.analizador.model.TipoToken;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Tokenizador {

    // Palabras clave de ejemplo (ajústalas a tu gramática .ccp)
    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList(
            "if", "else", "while", "for", "return", "int", "float", "double",
            "char", "std", "string", "bool", "true", "false", "void", "class"
    ));

    // Patrones básicos
    private static final Pattern PATRON = Pattern.compile(
            "(?<comentario>//.*$)" +                // 1 línea
                    "|(?<cadena>\"([^\"\\\\]|\\\\.)*\")" +  // "texto con \"escapes\""
                    "|(?<numero>\\b\\d+(?:\\.\\d+)?\\b)" +  // 123 o 12.34
                    "|(?<ident>\\b[_a-zA-Z][_a-zA-Z0-9]*\\b)" + // identificadores
                    "|(?<oper>[+\\-*/%=!<>|&]{1,2})" +      // operadores simples o dobles
                    "|(?<simbolo>[(){}#\\[\\];.,:])" +       // símbolos
                    "|(?<espacio>\\s+)"                     // espacios
            , Pattern.MULTILINE
    );

    public static List<Simbolo> analizar(String texto) {
        List<Simbolo> resultado = new ArrayList<>();

        String[] lineas = texto.split("\\R", -1); // conserva líneas vacías
        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            int fila = i + 1;

            Matcher m = PATRON.matcher(linea);
            while (m.find()) {
                String token;
                TipoToken tipo;

                if ((token = m.group("comentario")) != null) {
                    tipo = TipoToken.COMENTARIO;
                } else if ((token = m.group("cadena")) != null) {
                    tipo = TipoToken.CADENA;
                } else if ((token = m.group("numero")) != null) {
                    tipo = TipoToken.NUMERO;
                } else if ((token = m.group("ident")) != null) {
                    if (KEYWORDS.contains(token)) {
                        tipo = TipoToken.PALABRA_CLAVE;
                    } else {
                        tipo = TipoToken.IDENTIFICADOR;
                    }
                } else if ((token = m.group("oper")) != null) {
                    tipo = TipoToken.OPERADOR;
                } else if ((token = m.group("simbolo")) != null) {
                    tipo = TipoToken.SIMBOLO;
                } else {
                    token = m.group();
                    tipo = TipoToken.ESPACIO;
                }

                // Saltar espacios si no quieres que aparezcan en la tabla
                if (tipo == TipoToken.ESPACIO) continue;

                int colIni = m.start() + 1; // columnas 1-based
                int colFin = m.end();

                resultado.add(new Simbolo(token, tipo.texto(), fila, colIni, colFin));
            }
        }
        return resultado;
    }
}
