package com.analizador;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AnalizadorApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxml = new FXMLLoader(AnalizadorApp.class.getResource("analizador.fxml"));
        Scene scene = new Scene(fxml.load(), 1000, 600);
        stage.setTitle("Analizador de archivos .ccp");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
