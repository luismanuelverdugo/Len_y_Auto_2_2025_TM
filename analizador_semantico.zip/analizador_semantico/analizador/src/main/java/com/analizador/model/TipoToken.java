package com.analizador.model;
public enum TipoToken {
    PALABRA_CLAVE("Palabra clave"),
    IDENTIFICADOR("Identificador"),
    NUMERO("Número"),
    CADENA("Cadena"),
    OPERADOR("Operador"),
    SIMBOLO("Símbolo"),
    COMENTARIO("Comentario"),
    ESPACIO("Espacio");

    private final String texto;
    TipoToken(String t){ this.texto = t; }
    public String texto(){ return texto; }
}
