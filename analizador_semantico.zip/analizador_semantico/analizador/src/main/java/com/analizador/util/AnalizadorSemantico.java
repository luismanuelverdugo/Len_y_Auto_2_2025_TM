package com.analizador.util;

import com.analizador.model.ErrorSemantico;
import com.analizador.model.Simbolo;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AnalizadorSemantico {

    /** Punto de entrada original: solo desde el texto (mantener compatibilidad). */
    public static List<ErrorSemantico> analizar(String codigo) {
        List<ErrorSemantico> errores = new ArrayList<>();
        String[] lineas = codigo.split("\\R", -1);

        errores.addAll(detectarPunterosNulos(lineas));
        errores.addAll(detectarCondicionesIncorrectas(lineas));
        errores.addAll(detectarInicializacionYActualizacion(lineas));
        errores.addAll(detectarSobrecargaInvalida(lineas));

        return errores;
    }

    /** Analiza desde texto y tokens (para poder detectar variables sin inicializar y llamadas erróneas). */
    public static List<ErrorSemantico> analizar(String codigo, List<Simbolo> tokens) {
        List<ErrorSemantico> errores = analizar(codigo);
        errores.addAll(detectarUsoIncorrectoDeVariables(tokens));
        errores.addAll(detectarLlamadasErroneas(tokens));
        return errores;
    }

    // --------------------------------------------------------------
    // 1) Uso incorrecto de variables
    // --------------------------------------------------------------

    private static List<ErrorSemantico> detectarUsoIncorrectoDeVariables(List<Simbolo> tokens) {
        List<ErrorSemantico> errores = new ArrayList<>();


        Map<String, Boolean> inicializada = new HashMap<>();


        Set<String> tiposPrimitivos = new HashSet<>(Arrays.asList(
                "int", "float", "double", "char", "bool", "string", "String", "long", "short"
        ));

        for (int i = 0; i < tokens.size(); i++) {
            Simbolo actual = tokens.get(i);
            String tipoTok = actual.getTipo();
            String lexema  = actual.getToken();


            if (tipoTok.equals("Palabra clave") && tiposPrimitivos.contains(lexema)) {
                if (i + 1 < tokens.size()) {
                    Simbolo posibleId = tokens.get(i + 1);
                    if (posibleId.getTipo().equals("Identificador")) {
                        String nombreVar = posibleId.getToken();
                        boolean initEnMismaLinea = false;

                        if (i + 2 < tokens.size()) {
                            Simbolo maybeAsign = tokens.get(i + 2);
                            if (maybeAsign.getTipo().equals("Operador") && maybeAsign.getToken().equals("=")) {
                                initEnMismaLinea = true;
                            }
                        }

                        inicializada.put(nombreVar, initEnMismaLinea);
                    }
                }
                continue;
            }

            if (tipoTok.equals("Identificador")) {
                String nombreVar = lexema;

                if (i + 1 < tokens.size()) {
                    Simbolo maybeOp = tokens.get(i + 1);
                    if (maybeOp.getTipo().equals("Operador") && maybeOp.getToken().equals("=")) {

                        if (inicializada.containsKey(nombreVar)) {
                            inicializada.put(nombreVar, true);
                        } else {

                            inicializada.put(nombreVar, true);
                        }
                        continue;
                    }
                }

                if (inicializada.containsKey(nombreVar)) {
                    boolean yaInit = inicializada.get(nombreVar);
                    if (!yaInit) {
                        errores.add(new ErrorSemantico(
                                "Uso incorrecto de variables",
                                "La variable '" + nombreVar + "' se usa sin haberse inicializado.",
                                actual.getFila(),
                                actual.getColumnaI()
                        ));


                        inicializada.put(nombreVar, true);
                    }
                }
            }
        }

        return errores;
    }

    // --------------------------------------------------------------
    // 4) Condiciones incorrectas ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarCondicionesIncorrectas(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();

        Pattern pWhileConPuntoYComa = Pattern.compile("\\bwhile\\s*\\([^)]*\\)\\s*;");
        Pattern pConstWhile = Pattern.compile("\\bwhile\\s*\\(\\s*(?:true|1)\\s*\\)");
        Pattern pConstIfFalse = Pattern.compile("\\bif\\s*\\(\\s*(?:false|0)\\s*\\)");

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];

            Matcher m1 = pWhileConPuntoYComa.matcher(linea);
            if (m1.find()) {
                out.add(new ErrorSemantico(
                        "Condición incorrecta",
                        "Posible bucle infinito/ vacío: 'while (...) ;' (punto y coma tras la condición).",
                        i + 1, m1.start() + 1));
            }

            Matcher m2 = pConstWhile.matcher(linea);
            if (m2.find()) {
                out.add(new ErrorSemantico(
                        "Condición incorrecta",
                        "Bucle con condición constante verdadera: 'while(true)' o 'while(1)'.",
                        i + 1, m2.start() + 1));
            }

            Matcher m3 = pConstIfFalse.matcher(linea);
            if (m3.find()) {
                out.add(new ErrorSemantico(
                        "Condición incorrecta",
                        "if con condición siempre falsa: 'if(false)' o 'if(0)'.",
                        i + 1, m3.start() + 1));
            }
        }

        return out;
    }

    // --------------------------------------------------------------
    // 9) Inicialización y actualización de variables en bucles ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarInicializacionYActualizacion(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();

        Pattern pForIndice = Pattern.compile("\\bfor\\s*\\(\\s*int\\s+([_a-zA-Z]\\w*)\\s*=\\s*\\d+\\s*;");

        class Bucle {
            String idx;
            int filaInicio;
            int filaApertura;
            int filaCierre;
            Bucle(String idx){ this.idx = idx; }
        }
        List<Bucle> bucles = new ArrayList<>();

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];

            Matcher mFor = pForIndice.matcher(linea);
            if (mFor.find()) {
                Bucle b = new Bucle(mFor.group(1));
                b.filaInicio = i + 1;

                // localizar '{' que abre el cuerpo del for
                int aperturaFila = 0;
                for (int j = i; j < lineas.length; j++) {
                    String l = lineas[j];
                    int idxLlave = l.indexOf('{');
                    if (idxLlave >= 0) {
                        aperturaFila = j + 1;
                        break;
                    }
                    if (l.contains("for") && l.contains(")")) {
                        // si el for está en una sola línea tipo for(...){...
                        // ya debería haberse encontrado '{' en esta misma línea
                    }
                }
                b.filaApertura = aperturaFila;

                // encontrar la '}' correspondiente
                if (aperturaFila > 0) {
                    int nivel = 0;
                    for (int j = aperturaFila - 1; j < lineas.length; j++) {
                        String l = lineas[j];
                        for (int k = 0; k < l.length(); k++) {
                            char c = l.charAt(k);
                            if (c == '{') nivel++;
                            else if (c == '}') {
                                nivel--;
                                if (nivel == 0) {
                                    b.filaApertura = aperturaFila;
                                    b.filaCierre = j + 1;
                                    j = lineas.length;
                                    break;
                                }
                            }
                        }
                    }
                }

                bucles.add(b);
            }
        }

        // Ahora revisamos el cuerpo del bucle buscando reinicialización del contador
        Pattern pReini = Pattern.compile("\\b([_a-zA-Z]\\w*)\\s*=\\s*0\\b");
        for (Bucle b : bucles) {
            if (b.filaApertura == 0 || b.filaCierre == 0) continue;
            for (int f = b.filaApertura; f <= b.filaCierre; f++) {
                String linea = lineas[f - 1];
                Matcher mR = pReini.matcher(linea);
                while (mR.find()) {
                    String var = mR.group(1);
                    if (var.equals(b.idx)) {
                        out.add(new ErrorSemantico(
                                "Inicialización/Actualización",
                                "El contador del bucle '" + var + "' se reinicia dentro del for.",
                                f, mR.start(1) + 1));
                    }
                }
            }
        }

        return out;
    }

    // --------------------------------------------------------------
    // 10) Sobrecarga inválida / Redefinición de funciones ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarSobrecargaInvalida(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();

        Pattern pFirma = Pattern.compile(
                "\\b([_a-zA-Z]\\w*(?:\\s*\\*|\\s*&)?(?:\\s*::\\s*[_a-zA-Z]\\w*)?)\\s+" +
                        "([_a-zA-Z]\\w*)\\s*\\(([^)]*)\\)\\s*\\{?"
        );

        Map<String, String> firmas = new HashMap<>();
        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i].trim();
            Matcher m = pFirma.matcher(linea);
            if (m.find()) {
                String tipoRet = m.group(1).replaceAll("\\s+", " ").trim();
                String nombre = m.group(2);
                String params = normalizarParams(m.group(3));

                String firmaCanonica = nombre + "(" + params + ")";
                if (firmas.containsKey(firmaCanonica)) {
                    String existenteTipoRet = firmas.get(firmaCanonica);
                    if (!existenteTipoRet.equals(tipoRet)) {
                        out.add(new ErrorSemantico(
                                "Sobrecarga inválida",
                                "La función '" + nombre + "' se redefine con mismos parámetros pero distinto retorno.",
                                i + 1, 1));
                    } else {
                        out.add(new ErrorSemantico(
                                "Redefinición de función",
                                "La función '" + nombre + "' parece estar redefinida.",
                                i + 1, 1));
                    }
                } else {
                    firmas.put(firmaCanonica, tipoRet);
                }
            }
        }

        return out;
    }

    /** Convierte "int a, float b" -> "int,float" para comparar firmas. */
    private static String normalizarParams(String params) {
        if (params.trim().isEmpty()) return "";
        String[] partes = params.split(",");
        List<String> tipos = new ArrayList<>();
        for (String p : partes) {
            // quitamos el nombre de la variable y nos quedamos con el tipo "int", "float*", etc.
            String limpio = p.trim()
                    .replaceAll("\\s+", " ")
                    .replaceAll("\\b[_a-zA-Z]\\w*$", "") // quitar el posible nombre final
                    .trim();
            tipos.add(limpio);
        }
        return String.join(",", tipos);
    }

    // --------------------------------------------------------------
    // 11) Llamadas erróneas a funciones (utiliza la lista de tokens)
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarLlamadasErroneas(List<Simbolo> tokens) {
        List<ErrorSemantico> errores = new ArrayList<>();

        // 1. Recolectar funciones declaradas + cuántos parámetros aceptan.
        Map<String, Integer> funcionesDeclaradas = new HashMap<>();

        for (int i = 0; i < tokens.size(); i++) {
            // Buscamos patrón tipo: <tipoRet> <nombre>(param1, param2 ...)
            // más o menos: <Palabra clave|Identificador> <Identificador> "(" ... ")"
            if (i + 3 < tokens.size()) {
                Simbolo posibleTipo   = tokens.get(i);
                Simbolo posibleNombre = tokens.get(i + 1);
                Simbolo parentesis    = tokens.get(i + 2);

                // nombre de la función debe ser un Identificador y después "("
                if (posibleNombre.getTipo().equals("Identificador")
                        && parentesis.getToken().equals("(")) {

                    // ahora, asegurarnos de que antes hay algo que parece tipo de retorno
                    boolean retornoValido = false;
                    if (posibleTipo.getTipo().equals("Palabra clave") ||
                            posibleTipo.getTipo().equals("Identificador")) {
                        retornoValido = true;
                    }

                    if (retornoValido) {
                        String nombreFuncion = posibleNombre.getToken();
                        int numParams = contarParametros(tokens, i + 2);

                        if (numParams >= 0) {
                            funcionesDeclaradas.put(nombreFuncion, numParams);
                        }
                    }
                }
            }
        }

        // 2. Buscar llamadas a funciones y validar contra el mapa anterior
        for (int i = 0; i < tokens.size(); i++) {
            Simbolo s = tokens.get(i);
            if (esTipo(s.getTipo(), "Identificador")
                    && i + 1 < tokens.size()
                    && "(".equals(tokens.get(i + 1).getToken())) {

                String nombreFuncion = s.getToken();
                int parametrosLlamada = contarParametros(tokens, i + 1);

                if (!funcionesDeclaradas.containsKey(nombreFuncion)) {
                    errores.add(new ErrorSemantico(
                            "Llamada errónea a función",
                            "Se llamó a la función '" + nombreFuncion + "' sin estar declarada.",
                            s.getFila(), s.getColumnaI()));
                    continue;
                }

                int esperados = funcionesDeclaradas.get(nombreFuncion);
                if (esperados != parametrosLlamada) {
                    errores.add(new ErrorSemantico(
                            "Llamada errónea a función",
                            "La función '" + nombreFuncion + "' esperaba " + esperados +
                                    " argumento(s), pero recibió " + parametrosLlamada + ".",
                            s.getFila(), s.getColumnaI()));
                }
            }
        }

        return errores;
    }

    /**
     * Cuenta parámetros entre paréntesis empezando en el índice de "(".
     * Devuelve -1 si no encuentra el paréntesis de cierre.
     */
    private static int contarParametros(List<Simbolo> tokens, int idxParentesisApertura) {
        if (!tokens.get(idxParentesisApertura).getToken().equals("(")) {
            return -1;
        }

        int nivel = 0;
        int contadorComas = 0;
        boolean hayAlgo = false;

        for (int i = idxParentesisApertura; i < tokens.size(); i++) {
            String t = tokens.get(i).getToken();
            if (t.equals("(")) {
                nivel++;
            } else if (t.equals(")")) {
                nivel--;
                if (nivel == 0) {
                    if (!hayAlgo) {
                        return 0; // sin parámetros
                    } else {
                        return contadorComas + 1;
                    }
                }
            } else if (t.equals(",") && nivel == 1) {
                contadorComas++;
            } else {
                if (nivel == 1) {
                    // cualquier token entre "(" y ")" cuenta como "algo"
                    if (!t.equals(","))
                        hayAlgo = true;
                }
            }
        }
        return -1; // no encontramos cierre
    }

    // --------------------------------------------------------------
    // 13) Punteros/Referencias nulas ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarPunterosNulos(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();
        Pattern pAsign = Pattern.compile("\\b([_a-zA-Z]\\w*)\\s*=\\s*(?:null|nullptr)\\s*;");
        Pattern pUso = Pattern.compile("\\b([_a-zA-Z]\\w*)(\\s*(?:->|\\.)\\s*[_a-zA-Z]\\w*)");

        // Variables que fueron asignadas explícitamente a null / nullptr.
        Set<String> posiblementeNulas = new HashSet<>();

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];

            Matcher mAsign = pAsign.matcher(linea);
            while (mAsign.find()) {
                String var = mAsign.group(1);
                posiblementeNulas.add(var);
            }

            Matcher mUso = pUso.matcher(linea);
            while (mUso.find()) {
                String var = mUso.group(1);
                if (posiblementeNulas.contains(var)) {
                    out.add(new ErrorSemantico(
                            "Puntero/Referencia nula",
                            "Uso potencial de '" + var + "' que puede ser nulo/nullptr.",
                            i + 1, mUso.start(1) + 1));
                }
            }
        }

        return out;
    }

    /** Normaliza y compara tipos ignorando acentos y mayúsculas. */
    private static boolean esTipo(String actual, String esperado) {
        if (actual == null) return false;
        String a = sinAcentos(actual).toLowerCase(Locale.ROOT).trim();
        String e = sinAcentos(esperado).toLowerCase(Locale.ROOT).trim();
        return a.equals(e);
    }

    private static String sinAcentos(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "");
    }
}
