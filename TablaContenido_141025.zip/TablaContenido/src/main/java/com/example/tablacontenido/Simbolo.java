package com.example.tablacontenido;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Simbolo
{
    private final StringProperty token = new SimpleStringProperty();
    private final StringProperty tipo = new SimpleStringProperty();
    private final IntegerProperty fila = new SimpleIntegerProperty();
    private final IntegerProperty columnaI = new SimpleIntegerProperty();
    private final IntegerProperty columnaF = new SimpleIntegerProperty();

    public Simbolo(String token, String tipo, int fila, int columnaI, int columnaF)
    {
        this.token.set(token);
        this.tipo.set(tipo);
        this.fila.set(fila);
        this.columnaI.set(columnaI);
        this.columnaF.set(columnaF);
    }



    public String getToken() {
        return token.get();
    }

    public StringProperty tokenProperty() {
        return token;
    }

    public void setToken(String token) {
        this.token.set(token);
    }

    public String getTipo() {
        return tipo.get();
    }

    public StringProperty tipoProperty() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo.set(tipo);
    }

    public int getFila() {
        return fila.get();
    }

    public IntegerProperty filaProperty() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila.set(fila);
    }

    public int getColumnaI() {
        return columnaI.get();
    }

    public IntegerProperty columnaIProperty() {
        return columnaI;
    }

    public void setColumnaI(int columnaI) {
        this.columnaI.set(columnaI);
    }

    public int getColumnaF() {
        return columnaF.get();
    }

    public IntegerProperty columnaFProperty() {
        return columnaF;
    }

    public void setColumnaF(int columnaF) {
        this.columnaF.set(columnaF);
    }
}
