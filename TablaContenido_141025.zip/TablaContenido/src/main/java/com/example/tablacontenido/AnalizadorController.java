package com.example.tablacontenido;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class AnalizadorController
{
    @FXML
    private TextArea txtContenido;
    @FXML
    private TableView<Simbolo> tablaTokens;
    @FXML
    private TableColumn<Simbolo, String> colToken;
    @FXML
    private TableColumn<Simbolo, String> colTipo;
    @FXML
    private TableColumn<Simbolo, Integer> colFila;
    @FXML
    private TableColumn<Simbolo, Integer> colColIni;
    @FXML
    private TableColumn<Simbolo,Integer> colColFin;
    @FXML
    private Button btnImportar, btnAnalizar;
    @FXML
    private Label lblEstado;

    private final ObservableList<Simbolo> datos = FXCollections.observableArrayList();

    private void Initialize()
    {
        colToken.setCellValueFactory(c -> c.getValue().tokenProperty());
        colTipo.setCellValueFactory(c -> c.getValue().tipoProperty());
        colFila.setCellValueFactory(c -> c.getValue().filaProperty().asObject());
        colColIni.setCellValueFactory(c -> c.getValue().columnaIProperty().asObject());
        colColFin.setCellValueFactory(c -> c.getValue().columnaFProperty().asObject());

        tablaTokens.setItems(datos);
    }


    @FXML
    private void onBtnAnalizarClic()
    {
        FileChooser fc = new FileChooser();
        fc.setTitle("Seleciona un archivo .cpp");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos CCP (*.ccp)", "*.cpp"));
        File f = fc.showOpenDialog(txtContenido.getScene().getWindow());
        if (f == null) return;

        try
        {
            byte[] bytes = Files.readAllBytes(f.toPath());
            String contenido = new String(bytes, StandardCharsets.UTF_8);
            txtContenido.setText(contenido);
            lblEstado.setText("Archivo cargado: "+ f.getName());
            datos.clear();
        }
        catch (Exception ex)
        {
            mostrarError("Error al leer el archivo", ex.getMessage());
        }

    }

    private void mostrarError (String titulo, String detalle)
    {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Error");
        a.setHeaderText(titulo);
        a.setContentText(detalle);
        a.showAndWait();
    }

    public void ontBtnImportarClic(ActionEvent actionEvent) {
    }
}
