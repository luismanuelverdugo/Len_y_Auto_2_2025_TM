package com.example.tablacontenido;

public enum TipoToken {
    PALABRA_CLAVE("Palabra clave"),
    IDENTIFICADOR("Identificador"),
    NUMERO("Numero"),
    CADENA("Cadena"),
    OPERADOR("Operador"),
    SIMBOLO("Simbolo"),
    COMENTARIO("Comentario"),
    ESPACIO("Espacio");

    private final String texto;
    TipoToken(String t)
    {
        this.texto = t;
    }
    public String texto ()
    {
        return texto;
    }


}