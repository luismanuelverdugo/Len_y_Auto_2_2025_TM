package com.example.tablacontenido;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Tokenizador {

    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList("if", "else", "while", "for","std" ,"return", "int", "float", "double", "char", "string", "bool", "true", "false", "void", "class"));

    private static final Pattern PATRON = Pattern.compile("(?<comentario>//.*$)" +
            "|(?<cadena>\"([^\"\\\\]|\\\\.)*\")" +
            "|(?<numero>\\b\\d+(?:\\.\\d+)?\\b)" +
            "|(?<ident>\\b[_a-zA-Z][_a-zA-Z0-9]*\\b)+" +
            "|(?<oper>[+\\-*/%=!<>|&]{1,2})" +
            "|(?<simbolo>[(){}#\\[\\];.,:])+" +
            "|(?<espacio>\\s+)", Pattern.MULTILINE);

    public static List<Simbolo> analizar(String texto) {
        List<Simbolo> resultado = new ArrayList<>();

        String[] lineas = texto.split("\\R", -1);
        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            int fila = i + 1;
            System.out.println(fila);

            Matcher m = PATRON.matcher(linea);
            while (m.find()) {
                String token;
                TipoToken tipo;
                System.out.println("token");

                if ((token = m.group("comentario")) != null) {
                    tipo = TipoToken.COMENTARIO;
                    System.out.println("comentario");
                } else if ((token = m.group("cadena")) != null) {
                    tipo = TipoToken.CADENA;
                } else if ((token = m.group("numero")) != null) {
                    tipo = TipoToken.NUMERO;
                } else if ((token = m.group("ident")) != null) {
                    if (KEYWORDS.contains(token)) {
                        tipo = TipoToken.PALABRA_CLAVE;
                    } else {
                        tipo = TipoToken.IDENTIFICADOR;
                    }
                } else if ((token = m.group("oper")) != null) {
                    tipo = TipoToken.OPERADOR;
                } else if ((token = m.group("simbolo")) != null) {
                    tipo = TipoToken.SIMBOLO;
                }
                else {
                    token = m.group();
                    tipo = TipoToken.ESPACIO;
                }

                if( tipo == TipoToken.ESPACIO) continue;

                int colIni = m.start() + 1;
                System.out.println(colIni);
                int colFin = m.end();
                System.out.println(colFin);

                resultado.add(new Simbolo(token, tipo.texto(), fila, colIni, colFin));
            }
        }

return resultado;
    }
}

