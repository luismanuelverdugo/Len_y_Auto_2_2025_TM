// errores_prueba.cpp
#include <iostream>
#include <string>
using namespace std;

struct Demo {
    int valor;
    void metodo() { cout << "ok\n"; }
};

int operar(int a) {               // --- Sobrecarga válida #1 (base)
    return a + 1;
}

void operar(int a) {              // --- 4) Sobrecarga inválida (misma firma, distinto retorno)
    cout << "operar: " << a << "\n";
}

int suma(int a, int b) {          // --- Función #1
    return a + b;
}

int suma(int a, int b) {          // --- 4) Duplicada exacta (misma firma y retorno)
    return a - b;
}

int main() {
    // --- 1) Punteros / referencias nulas
    Demo* p = nullptr;
    p->metodo();                  // Uso potencial de puntero nulo

    Demo* q = nullptr; q->valor = 10; // Otro uso nulo

    // --- 2) Condiciones incorrectas
    int i = 3;
    while (i > 0);               // punto y coma -> bucle vacío/infinito
    {
        i--;                     // este bloque NO pertenece al while de arriba
    }

    while (true) {               // condición constante verdadera
        cout << "loop\n";
        break;                   // (aunque aquí rompa, el detector lo reportará)
    }

    if (0) {                     // condición siempre falsa -> bloque muerto
        cout << "nunca se imprime\n";
    }

    // --- 3) Inicialización / actualización
    int x;                       // declarado sin inicializar
    cout << x << "\n";           // uso antes de asignar (heurístico)

    for (int k = 0; k < 5; k++) {
        cout << k << " ";
        if (k == 2) {
            k = 0;               // reinicio del contador dentro del for
        }
    }
    cout << "\n";

    return 0;
}
