module com.analizador.analizador {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;

    opens com.analizador to javafx.fxml;
    exports com.analizador;
    exports com.analizador.controller;
    opens com.analizador.controller to javafx.fxml;
    exports com.analizador.model;
    opens com.analizador.model to javafx.fxml;
    exports com.analizador.util;
    opens com.analizador.util to javafx.fxml;
}