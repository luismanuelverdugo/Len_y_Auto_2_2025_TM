package com.analizador.model;

import javafx.beans.property.*;

public class Simbolo {
    private final StringProperty token = new SimpleStringProperty();
    private final StringProperty tipo = new SimpleStringProperty();
    private final IntegerProperty fila = new SimpleIntegerProperty();
    private final IntegerProperty columnaI = new SimpleIntegerProperty();
    private final IntegerProperty columnaF = new SimpleIntegerProperty();

    public Simbolo(String token, String tipo, int fila, int columnaI, int columnaF) {
        this.token.set(token);
        this.tipo.set(tipo);
        this.fila.set(fila);
        this.columnaI.set(columnaI);
        this.columnaF.set(columnaF);
    }

    // Getters JavaFX properties (necesarios para TableView)
    public StringProperty tokenProperty() { return token; }
    public StringProperty tipoProperty() { return tipo; }
    public IntegerProperty filaProperty() { return fila; }
    public IntegerProperty columnaIProperty() { return columnaI; }
    public IntegerProperty columnaFProperty() { return columnaF; }

    // Getters sencillos (opcional)
    public String getToken() { return token.get(); }
    public String getTipo() { return tipo.get(); }
    public int getFila() { return fila.get(); }
    public int getColumnaI() { return columnaI.get(); }
    public int getColumnaF() { return columnaF.get(); }
}
