package com.analizador.model;

import javafx.beans.property.*;

public class ErrorSemantico {
    private final StringProperty tipo = new SimpleStringProperty();
    private final StringProperty mensaje = new SimpleStringProperty();
    private final IntegerProperty fila = new SimpleIntegerProperty();
    private final IntegerProperty columna = new SimpleIntegerProperty();

    public ErrorSemantico(String tipo, String mensaje, int fila, int columna) {
        this.tipo.set(tipo);
        this.mensaje.set(mensaje);
        this.fila.set(fila);
        this.columna.set(columna);
    }

    public StringProperty tipoProperty() { return tipo; }
    public StringProperty mensajeProperty() { return mensaje; }
    public IntegerProperty filaProperty() { return fila; }
    public IntegerProperty columnaProperty() { return columna; }
}
