package com.analizador.controller;

import com.analizador.util.AnalizadorSemantico;
import com.analizador.model.ErrorSemantico;
import com.analizador.model.Simbolo;
import com.analizador.util.Tokenizador;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;

public class AnalizadorController {

    @FXML private TextArea txtContenido;

    // TOKENS
    @FXML private TableView<Simbolo> tablaTokens;
    @FXML private TableColumn<Simbolo, String> colToken;
    @FXML private TableColumn<Simbolo, String> colTipo;
    @FXML private TableColumn<Simbolo, Integer> colFila;
    @FXML private TableColumn<Simbolo, Integer> colColIni;
    @FXML private TableColumn<Simbolo, Integer> colColFin;

    // ERRORES
    @FXML private TableView<ErrorSemantico> tablaErrores;
    @FXML private TableColumn<ErrorSemantico, String> colErrTipo;
    @FXML private TableColumn<ErrorSemantico, String> colErrMensaje;
    @FXML private TableColumn<ErrorSemantico, Integer> colErrFila;
    @FXML private TableColumn<ErrorSemantico, Integer> colErrCol;

    @FXML private Button btnImportar, btnAnalizar;
    @FXML private Label lblEstado;
    @FXML
    private SplitPane splitMain;
    @FXML private SplitPane splitRight;


    @FXML private TextArea txtLineas;

    private final ObservableList<Simbolo> datosTokens = FXCollections.observableArrayList();
    private final ObservableList<ErrorSemantico> datosErrores = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        // TOKENS
        colToken.setCellValueFactory(c -> c.getValue().tokenProperty());
        colTipo.setCellValueFactory(c -> c.getValue().tipoProperty());
        colFila.setCellValueFactory(c -> c.getValue().filaProperty().asObject());
        colColIni.setCellValueFactory(c -> c.getValue().columnaIProperty().asObject());
        colColFin.setCellValueFactory(c -> c.getValue().columnaFProperty().asObject());
        tablaTokens.setItems(datosTokens);

        // ERRORES
        colErrTipo.setCellValueFactory(c -> c.getValue().tipoProperty());
        colErrMensaje.setCellValueFactory(c -> c.getValue().mensajeProperty());
        colErrFila.setCellValueFactory(c -> c.getValue().filaProperty().asObject());
        colErrCol.setCellValueFactory(c -> c.getValue().columnaProperty().asObject());
        tablaErrores.setItems(datosErrores);

        splitMain.setDividerPositions(0.40); // 40% izquierda, 55% derecha
        splitRight.setDividerPositions(0.55);

        txtLineas.scrollTopProperty().bindBidirectional(txtContenido.scrollTopProperty());
        txtLineas.scrollLeftProperty().unbind();
        txtLineas.setScrollLeft(0);

        txtContenido.textProperty().addListener((obs, oldV, newV) -> actualizarNumerosLinea());
        actualizarNumerosLinea();


    }

    private void actualizarNumerosLinea() {
        // contar líneas del TextArea (siempre al menos 1)
        String text = txtContenido.getText();
        int lineas = (text == null || text.isEmpty()) ? 1 : (int) text.chars().filter(ch -> ch == '\n').count() + 1;

        // construir "1\n2\n3\n..."
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lineas; i++) {
            sb.append(i).append('\n');
        }
        txtLineas.setText(sb.toString());

        // mantener scroll horizontal del gutter en cero
        txtLineas.setScrollLeft(0);
    }


    @FXML
    private void onImportar() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Selecciona un archivo .cpp");
        fc.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Archivos CPP/CCP (*.cpp, *.ccp)", "*.cpp", "*.ccp")
        );
        File f = fc.showOpenDialog(txtContenido.getScene().getWindow());
        if (f == null) return;

        try {
            byte[] bytes = Files.readAllBytes(f.toPath());
            String contenido = new String(bytes, StandardCharsets.UTF_8);
            txtContenido.setText(contenido);
            lblEstado.setText("Archivo cargado: " + f.getName());
            datosTokens.clear();
            datosErrores.clear();
        } catch (Exception ex) {
            mostrarError("Error al leer el archivo", ex.getMessage());
        }
    }

    @FXML
    private void onAnalizar() {
        datosTokens.clear();
        datosErrores.clear();

        String texto = txtContenido.getText();
        if (texto == null || texto.isBlank()) {
            lblEstado.setText("No hay contenido para analizar.");
            return;
        }

        // 1) Tokens
        List<Simbolo> lista = Tokenizador.analizar(texto);
        datosTokens.addAll(lista);

        // 2) Errores semánticos (tus 4 detectores)
        List<ErrorSemantico> errs = AnalizadorSemantico.analizar(texto, lista);
        datosErrores.addAll(errs);

        lblEstado.setText("Tokens: " + lista.size() + " | Errores: " + errs.size());
    }

    private void mostrarError(String titulo, String detalle) {
        Alert a = new Alert(Alert.AlertType.ERROR);
        a.setTitle("Error");
        a.setHeaderText(titulo);
        a.setContentText(detalle);
        a.showAndWait();
    }
}

