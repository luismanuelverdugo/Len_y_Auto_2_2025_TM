package com.analizador.util;

import com.analizador.model.ErrorSemantico;
import com.analizador.model.Simbolo;

import java.text.Normalizer;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AnalizadorSemantico {

    /** Punto de entrada original: solo desde el texto (mantener compatibilidad). */
    public static List<ErrorSemantico> analizar(String codigo) {
        List<ErrorSemantico> errores = new ArrayList<>();
        String[] lineas = codigo.split("\\R", -1);

        errores.addAll(detectarPunterosNulos(lineas));
        errores.addAll(detectarCondicionesIncorrectas(lineas));
        errores.addAll(detectarInicializacionYActualizacion(lineas));
        errores.addAll(detectarSobrecargaInvalida(lineas));

        return errores;
    }

    /** NUEVO: Analiza desde texto y además corre el detector de llamadas erróneas usando tokens. */
    public static List<ErrorSemantico> analizar(String codigo, List<Simbolo> tokens) {
        List<ErrorSemantico> errores = analizar(codigo); // conserva tus 4 detectores
        errores.addAll(detectarLlamadasErroneas(tokens)); // agrega el nuevo
        return errores;
    }

    // --------------------------------------------------------------
    // 13) Punteros/Referencias nulas ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarPunterosNulos(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();
        Pattern pAsign = Pattern.compile("\\b([_a-zA-Z]\\w*)\\s*=\\s*(?:null|nullptr)\\s*;");
        Pattern pUso = Pattern.compile("\\b([_a-zA-Z]\\w*)(\\s*(?:->|\\.)\\s*[_a-zA-Z]\\w*)");

        Map<String, int[]> nulos = new HashMap<>(); // var -> [fila, colIni]

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            Matcher mA = pAsign.matcher(linea);
            while (mA.find()) {
                String var = mA.group(1);
                nulos.put(var, new int[]{i + 1, mA.start(1) + 1});
            }
        }

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];
            Matcher mU = pUso.matcher(linea);
            while (mU.find()) {
                String var = mU.group(1);
                if (nulos.containsKey(var)) {
                    int col = mU.start(1) + 1;
                    out.add(new ErrorSemantico(
                            "Puntero/Referencia nula",
                            "Uso de '" + var + "' posiblemente nulo (asignado a null/nullptr) antes de verificar.",
                            i + 1, col));
                }
            }
        }
        return out;
    }

    // --------------------------------------------------------------
    // 4) Condiciones incorrectas ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarCondicionesIncorrectas(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();

        Pattern pWhileConPuntoYComa = Pattern.compile("\\bwhile\\s*\\([^)]*\\)\\s*;");
        Pattern pConstWhile = Pattern.compile("\\bwhile\\s*\\(\\s*(?:true|1)\\s*\\)");
        Pattern pConstIfFalse = Pattern.compile("\\bif\\s*\\(\\s*(?:false|0)\\s*\\)");

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];

            Matcher m1 = pWhileConPuntoYComa.matcher(linea);
            if (m1.find()) {
                out.add(new ErrorSemantico(
                        "Condición incorrecta",
                        "Posible bucle infinito/ vacío: 'while (...) ;' (punto y coma tras la condición).",
                        i + 1, m1.start() + 1));
            }

            Matcher m2 = pConstWhile.matcher(linea);
            if (m2.find()) {
                out.add(new ErrorSemantico(
                        "Condición incorrecta",
                        "Bucle con condición constante verdadera: 'while(true)' o 'while(1)'.",
                        i + 1, m2.start() + 1));
            }

            Matcher m3 = pConstIfFalse.matcher(linea);
            if (m3.find()) {
                out.add(new ErrorSemantico(
                        "Condición incorrecta",
                        "Bloque muerto: 'if(false)' o 'if(0)'.",
                        i + 1, m3.start() + 1));
            }
        }
        return out;
    }

    // --------------------------------------------------------------
    // 8) Inicialización/Actualización ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarInicializacionYActualizacion(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();

        Pattern pDeclSinInit = Pattern.compile("\\b(int|double|float|char|bool|long|short)\\s+([_a-zA-Z]\\w*)\\s*;");
        Pattern pAsign = Pattern.compile("\\b([_a-zA-Z]\\w*)\\s*=");
        Pattern pUso = Pattern.compile("\\b([_a-zA-Z]\\w*)\\b");
        Pattern pForIndice = Pattern.compile("\\bfor\\s*\\(\\s*(?:int|long|short)?\\s*([_a-zA-Z]\\w*)\\s*=.*?;");

        Map<String, Boolean> inicializada = new HashMap<>();

        class Bucle {
            String idx;
            int filaInicio;
            int filaApertura;
            int filaCierre;
            Bucle(String idx){ this.idx = idx; }
        }
        List<Bucle> bucles = new ArrayList<>();

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];

            Matcher mFor = pForIndice.matcher(linea);
            if (mFor.find()) {
                Bucle b = new Bucle(mFor.group(1));
                b.filaInicio = i + 1;

                int aperturaFila = -1;
                for (int j = i; j < Math.min(i + 3, lineas.length); j++) {
                    int pos = lineas[j].indexOf('{');
                    if (pos >= 0) { aperturaFila = j + 1; break; }
                }
                if (aperturaFila != -1) {
                    int nivel = 0;
                    for (int j = aperturaFila - 1; j < lineas.length; j++) {
                        String l = lineas[j];
                        for (int k = 0; k < l.length(); k++) {
                            char c = l.charAt(k);
                            if (c == '{') nivel++;
                            else if (c == '}') {
                                nivel--;
                                if (nivel == 0) {
                                    b.filaApertura = aperturaFila;
                                    b.filaCierre = j + 1;
                                    j = lineas.length;
                                    break;
                                }
                            }
                        }
                    }
                }
                bucles.add(b);
            }
        }

        Set<String> tipos = new HashSet<>(Arrays.asList("int","double","float","char","bool","long","short"));

        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i];

            Matcher mDecl = pDeclSinInit.matcher(linea);
            while (mDecl.find()) {
                String nombre = mDecl.group(2);
                inicializada.putIfAbsent(nombre, Boolean.FALSE);
            }

            Matcher mAs = pAsign.matcher(linea);
            while (mAs.find()) {
                String nombre = mAs.group(1);
                if (!tipos.contains(nombre)) {
                    inicializada.put(nombre, Boolean.TRUE);
                }
            }

            Matcher mUso = pUso.matcher(linea);
            while (mUso.find()) {
                String nombre = mUso.group(1);
                if (inicializada.containsKey(nombre) && Boolean.FALSE.equals(inicializada.get(nombre))) {
                    if (linea.matches(".*\\b(int|double|float|char|bool|long|short)\\s+" + nombre + "\\s*;.*"))
                        continue;

                    out.add(new ErrorSemantico(
                            "Inicialización/Actualización",
                            "Uso de variable '" + nombre + "' antes de inicializar.",
                            i + 1, mUso.start(1) + 1));
                }
            }
        }

        Pattern pReini = Pattern.compile("\\b([_a-zA-Z]\\w*)\\s*=\\s*0\\b");
        for (Bucle b : bucles) {
            if (b.filaApertura == 0 || b.filaCierre == 0) continue;
            for (int f = b.filaApertura; f <= b.filaCierre; f++) {
                String linea = lineas[f - 1];
                Matcher mR = pReini.matcher(linea);
                while (mR.find()) {
                    String var = mR.group(1);
                    if (var.equals(b.idx)) {
                        out.add(new ErrorSemantico(
                                "Inicialización/Actualización",
                                "El contador del bucle '" + var + "' se reinicia dentro del for.",
                                f, mR.start(1) + 1));
                    }
                }
            }
        }

        return out;
    }

    // --------------------------------------------------------------
    // 18) Sobrecarga inválida ( Abraham )
    // --------------------------------------------------------------
    private static List<ErrorSemantico> detectarSobrecargaInvalida(String[] lineas) {
        List<ErrorSemantico> out = new ArrayList<>();

        Pattern pFirma = Pattern.compile(
                "\\b([_a-zA-Z]\\w*(?:\\s*\\*|\\s*&)?(?:\\s*::\\s*[_a-zA-Z]\\w*)?)\\s+" +
                        "([_a-zA-Z]\\w*)\\s*\\(([^)]*)\\)\\s*\\{?");

        Map<String, String> firmas = new HashMap<>();
        for (int i = 0; i < lineas.length; i++) {
            String linea = lineas[i].trim();
            Matcher m = pFirma.matcher(linea);
            if (m.find()) {
                String tipoRet = m.group(1).replaceAll("\\s+", " ").trim();
                String nombre = m.group(2);
                String params = normalizarParams(m.group(3));

                String clave = nombre + "(" + params + ")";
                if (firmas.containsKey(clave)) {
                    String retPrev = firmas.get(clave);
                    if (!retPrev.equals(tipoRet)) {
                        out.add(new ErrorSemantico(
                                "Sobrecarga inválida",
                                "Firma repetida con distinto retorno: " + clave +
                                        ". Retornos: '" + retPrev + "' vs '" + tipoRet + "'.",
                                i + 1, m.start(2) + 1));
                    } else {
                        out.add(new ErrorSemantico(
                                "Sobrecarga inválida",
                                "Método/función duplicada: " + clave + ".",
                                i + 1, m.start(2) + 1));
                    }
                } else {
                    firmas.put(clave, tipoRet);
                }
            }
        }
        return out;
    }

    private static String normalizarParams(String paramsCrudos) {
        if (paramsCrudos == null) return "";
        String p = paramsCrudos.trim();
        if (p.isEmpty()) return "";
        String[] partes = p.split(",");
        List<String> tipos = new ArrayList<>();
        for (String parte : partes) {
            String t = parte.trim();
            t = t.replaceAll("\\bconst\\b", "")
                    .replaceAll("\\s*\\*\\s*", "*")
                    .replaceAll("\\s*&\\s*", "&")
                    .replaceAll("\\s+", " ");
            t = t.replaceAll("\\s+[_a-zA-Z]\\w*$", "");
            tipos.add(t.trim());
        }
        return String.join(",", tipos);
    }

    // ==============================================================
    // Pashy
    // ==============================================================

    private static List<ErrorSemantico> detectarLlamadasErroneas(List<Simbolo> tokens) {
        List<ErrorSemantico> errores = new ArrayList<>();
        if (tokens == null || tokens.isEmpty()) return errores;

        Map<String, Integer> funcionesDeclaradas = new HashMap<>();

        // 1) Buscar firmas DECLARADAS (heurística básica):
        //    Identificador precedido por "Palabra clave" (tipo) y seguido de "("
        for (int i = 0; i < tokens.size(); i++) {
            Simbolo s = tokens.get(i);
            if (esTipo(s.getTipo(), "Identificador") && i > 0 && esTipo(tokens.get(i - 1).getTipo(), "Palabra clave")) {
                if (i + 1 < tokens.size() && "(".equals(tokens.get(i + 1).getToken())) {
                    int parametros = contarParametros(tokens, i + 1);
                    funcionesDeclaradas.put(s.getToken(), parametros);
                }
            }
        }

        // 2) Verificar LLAMADAS: identificador seguido de "("
        for (int i = 0; i < tokens.size(); i++) {
            Simbolo s = tokens.get(i);
            if (esTipo(s.getTipo(), "Identificador") && i + 1 < tokens.size() && "(".equals(tokens.get(i + 1).getToken())) {
                String nombreFuncion = s.getToken();
                int parametrosLlamada = contarParametros(tokens, i + 1);

                if (!funcionesDeclaradas.containsKey(nombreFuncion)) {
                    errores.add(new ErrorSemantico(
                            "Llamada errónea a función",
                            "Se llamó a la función '" + nombreFuncion + "' sin estar declarada.",
                            s.getFila(), s.getColumnaI()));
                    continue;
                }

                int esperados = funcionesDeclaradas.get(nombreFuncion);
                if (esperados != parametrosLlamada) {
                    errores.add(new ErrorSemantico(
                            "Llamada errónea a función",
                            "La función '" + nombreFuncion + "' esperaba " + esperados +
                                    " parámetro(s), pero recibió " + parametrosLlamada + ".",
                            s.getFila(), s.getColumnaI()));
                }
            }
        }

        return errores;
    }

    /** Cuenta argumentos dentro de los paréntesis que empiezan en indiceParentesis. */
    private static int contarParametros(List<Simbolo> tokens, int indiceParentesis) {
        int contador = 0;
        int i = indiceParentesis + 1;
        boolean esperandoArgumento = true;

        for (; i < tokens.size(); i++) {
            String t = tokens.get(i).getToken();
            if (")".equals(t)) break;

            if (",".equals(t)) {
                if (esperandoArgumento) return -1; // coma doble o final
                esperandoArgumento = true;
            } else if (!"(".equals(t) && !")".equals(t)) {
                // Consideramos como argumento tokens típicos:
                // Identificador, Número (con o sin acento), Cadena
                if (!esperandoArgumento) continue;
                String tipoTok = tokens.get(i).getTipo();
                if (esTipo(tipoTok, "Identificador") || esTipo(tipoTok, "Numero") || esTipo(tipoTok, "Número") || esTipo(tipoTok, "Cadena")) {
                    contador++;
                    esperandoArgumento = false;
                }
            }
        }
        return contador;
    }

    /** Normaliza y compara tipos ignorando acentos y mayúsculas. */
    private static boolean esTipo(String actual, String esperado) {
        if (actual == null) return false;
        String a = sinAcentos(actual).toLowerCase(Locale.ROOT).trim();
        String e = sinAcentos(esperado).toLowerCase(Locale.ROOT).trim();
        return a.equals(e);
    }

    private static String sinAcentos(String s) {
        String n = Normalizer.normalize(s, Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "");
    }
}
