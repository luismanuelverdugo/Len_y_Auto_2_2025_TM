package com.example.tablacontenido.models;
import java.io.*;
import java.util.regex.*;

public class tokens {

    private Pattern Var=Pattern.compile("\\b(int | float | double | char) \\s+(\\w+)\\s*;");
    private Pattern funcion=Pattern.compile("\\b(void | int | float | double | char) \\s+(\\w+)\\s*\\(([^)]*)\\)");
    private Pattern identificador=Pattern.compile("\\b([a-zA-Z_]\\w*)\\b*");

    public void analizador(File file) throws IOException {
        BufferedReader lector = new BufferedReader(new FileReader(file));
        String linea;
        boolean dentrofuncion=false;

        while((linea = lector.readLine()) != null) {
            linea=linea.trim();
            if (linea.isEmpty()) continue;

            //PARA VERIFICAR LA FUNCIÒN

            Matcher funcionigual = funcion.matcher(linea);
            Matcher varigual = Var.matcher(linea);
            Matcher identificadorigual = identificador.matcher(linea);

            
        }
    }
}
